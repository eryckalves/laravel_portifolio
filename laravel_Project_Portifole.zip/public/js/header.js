$( document ).ready(function() {

    //menu-toggle navbar
    const selectElement = function(element)
    {
        return document.querySelector(element);
    }

    let menuToggler = selectElement('.menu-toggle');
    let body = selectElement('body');

    menuToggler.addEventListener('click', addToggle );

    function addToggle() {
        body.classList.toggle('open');
    }

    //scroll on click About US
    $("#contact").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".footer").offset().top
        }, 500);
    });

    //scroll on click Gallery
    $("#gallery").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".gallery-favorite").offset().top
        }, 500);
    });

    //scroll on click Tecnology
    $("#tecnology").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".tecnology-used").offset().top
        }, 500);
    });

    //scroll on click Team
    $("#team").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".team-our-ppl").offset().top
        }, 500);
    });

    //scroll on click test
    $("#test").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".tecnology-used").offset().top
        }, 500);
    });

});


