$( document ).ready(function() {

    //Scroll reveal
    window.sr = ScrollReveal({ reset: true });
    console.log(sr);
    sr.reveal('.animate-left',
    {
        origin:'left',
        duration: 1000,
        distance: '20rem',
        delay: 300
    });

    sr.reveal('.animate-right',
    {
        origin:'right',
        duration: 1000,
        distance: '20rem',
        delay: 600
    });

    sr.reveal('.animate-top',
    {
        origin:'top',
        duration: 1000,
        distance: '20rem',
        delay: 600
    });

    sr.reveal('.animate-bottom',
    {
        origin:'bottom',
        duration: 1000,
        distance: '20rem',
        delay: 600
    });


    //scroll on click About US
    $("#aboutUs, #socialMedia").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".footer").offset().top
        }, 500);
    });

    //scroll on click Gallery
    $("#gallery").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".gallery-favorite").offset().top
        }, 500);
    });

    //scroll on click Tecnology
    $("#tecnology").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".tecnology-used").offset().top
        }, 500);
    });

    //scroll on click Team
    $("#team").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".team-our-ppl").offset().top
        }, 500);
    });

    //scroll on click discovery
    $("#discovery").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".discovery").offset().top
        }, 500);
    });

    //scroll on click test
    $("#test").click(function (e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(".test").offset().top
        }, 500);
    });


    //chart 1

    var ctx = document.getElementById('myChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'November', 'December '],
            datasets: [{
                data: [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(153, 55, 25, 0.2)',
                    'rgba(14, 55, 255, 0.2)',
                    'rgba(255, 0, 255, 0.2)',
                    'rgba(13, 255, 13, 0.2)',
                    'rgba(100, 13, 50, 0.2)',
                    'rgba(133, 50, 22, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(153, 55, 25, 1)',
                    'rgba(14, 55, 255, 1)',
                    'rgba(255, 0, 255, 1)',
                    'rgba(13, 255, 13, 1)',
                    'rgba(100, 13, 50, 1)',
                    'rgba(133, 50, 22, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            },
            legend: { display: false },
            title: {
              display: true,
              text: '# days of months'
            }
        }
    });

    //chart 2

    var horizontal = document.getElementById('myChartHorizontal').getContext('2d');
    var myChartHorizontal = new Chart(horizontal, {
        type: 'horizontalBar',
        data: {
          labels: ["Africa", "Asia", "Europe", "Latin America", "North America"],
          datasets: [
            {
              label: "Population (millions)",
              backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
              data: [2478,5267,734,784,433]
            }
          ]
        },
        options: {
          legend: { display: false },
          title: {
            display: true,
            text: 'Predicted world population (millions) in 2050'
          }
        }
    });

    //SWIPER

    var swiper = new Swiper('.swiper-container', {
        effect: 'coverflow',
        grabCursor: true,
        centeredSlides: true,
        slidesPerView: 'auto',
        loop: true,
        coverflowEffect: {
          rotate: 50,
          stretch: 0,
          depth: 700,
          modifier: 1,
          slideShadows : true,
        },
        pagination: {
          el: '.swiper-pagination',
        },
      });

});
